/************************ Adafruit IO Config *******************************/
// visit io.adafruit.com if you need to create an account,
// or if you need your Adafruit IO key.
#define IO_USERNAME  "outdoorsensing"
#define IO_KEY       "aio_JPct47rppv7DSvyE8Igww3AjsJD8"
/******************************* WIFI **************************************/

#define WIFI_SSID   "vallauri.docenti"
#define WIFI_PASS   "fossano-vallauri"
#include <AdafruitIO_WiFi.h>
AdafruitIO_WiFi io(IO_USERNAME, IO_KEY, WIFI_SSID, WIFI_PASS);
