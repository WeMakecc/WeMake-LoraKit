#define MXbuf 50
#define MXVAR 50
#define RXpin  D3
#define TXpin  D4  //(non usato come hardware)
//#include <Wire.h>
#include <ESP8266WiFi.h>  // commentare se si usa sparkfun
#include <ESP8266WiFiMulti.h>
#include <SoftwareSerial.h>
ESP8266WiFiMulti WiFiMulti;
SoftwareSerial mySerial1(RXpin,TXpin);
//==============================================================================
//------------------------------------------------------------------------------
uint16_t    ID_TX   = 0;
uint16_t    npacket = 0;
uint16_t    vBatTX  = 0;
uint16_t    nRSSI = 0;
uint16_t    Length  = 0;
uint16_t    i =     0;
uint16_t    nbyte = 0;
uint16_t    nbyteRec = 0;
uint8_t     flag =  0;
uint8_t     flagEnd =  0;
uint8_t     buf[MXbuf];
uint8_t     primo = 0;
uint8_t     err = 0;
