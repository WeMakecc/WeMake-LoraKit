//  packets to be received
uint16_t ID1 = 40001;
typedef struct packet40001{
float      Temp;    
float      Humi;    
};
uint16_t ID2 = 40002;
typedef struct packet40002{
float      Temp;    
float      Humi;    
};
uint16_t ID3 = 40003;
typedef struct packet40003{
float      Temp;    
float      Humi;    
};
uint16_t ID4 = 40004;
typedef struct packet40004{
float      Temp;    
float      Humi;    
};
typedef union pluto {
  packet40001 Data40001;            //  Data is the name of the structure to be joined to bufVar
  packet40002 Data40002;            
  packet40003 Data40003;            
  packet40004 Data40004;            
  byte bufVar[MXVAR];   //  array of bytes to be joined with the structure
};
pluto minni;     
//
AdafruitIO_Feed *Temp1 = io.feed("Temp1");
AdafruitIO_Feed *Humi1 = io.feed("Humi1");
AdafruitIO_Feed *vBat1 = io.feed("vBat1");
AdafruitIO_Feed *Temp2 = io.feed("Temp2");
AdafruitIO_Feed *Humi2 = io.feed("Humi2");
AdafruitIO_Feed *vBat2 = io.feed("vBat2");
AdafruitIO_Feed *Temp3 = io.feed("Temp3");
AdafruitIO_Feed *Humi3 = io.feed("Humi3");
AdafruitIO_Feed *vBat3 = io.feed("vBat3");
AdafruitIO_Feed *Temp4 = io.feed("Temp4");
AdafruitIO_Feed *Humi4 = io.feed("Humi4");
AdafruitIO_Feed *vBat4 = io.feed("vBat4");
