//#include <Wire.h>
#include <RH_RF95.h>
#define lcdAddress 0x27
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(lcdAddress,16,2); 
#define RXpin  7
#define TXpin  3
#include <SoftwareSerial.h>
SoftwareSerial mySerial1(RXpin, TXpin); //RX, TX    for ESP8266 

byte error = 0;
byte LCDpresent = 0;

#define MXbuf      50
#define MXVAR      50
#define RFM95_RST   4
/*
//  for ProMicro
#define RFM95_CS   10
#define RFM95_INT   7
#define VBATPIN    A9   //  to be connected with 2 x 100K between + and - of the battery
#define LEDpin     17   //  for blinking
*/

//  for TTGO
#define RFM95_CS   10
#define RFM95_INT   2  
#define VBATPIN    A0    // connected with D6
#define LEDpin      8   //  for blinking

/*
//  for Feather 32u4
#define RFM95_CS  8
#define RFM95_INT 7
#define VBATPIN   A9  
#define LEDpin    13   //  for blinking
*/

// Singleton instance of the radio driver
RH_RF95 rf95(RFM95_CS, RFM95_INT);


byte      Roger   = 0;
byte      len     = 0;  
uint16_t  ID_TX   = 0;       //  TX ID received from message header
uint16_t  Length  = 0;       //  message Length from TX header
uint16_t  npacket = 0;       //  message number from TX header
uint16_t  vBatTX  = 0;      //   Battery voltage from TX header
uint16_t  nRSSI   = 0;      //  received RSSI
byte      buf[MXbuf];
int i = 0;
