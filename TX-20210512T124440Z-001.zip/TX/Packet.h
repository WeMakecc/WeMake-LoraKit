/* In this folder you must put the variables that you want to transmit in a message 
  other than the fixed ones (ID_TX, Length, vBatTX, npacket.
  Variables, regardless of their type (int, float, char etc.), must be declared 
  inside the "typedef struct".
  When I have to call one of these variables in the program, I call it like this:
  minni.Data40001.Temp 
  40001 is the ID of the transmitter
*/
//  40001;            byte 8 + 8; 
uint16_t ID_TX = 40001;
uint16_t Length = 16;

typedef struct packet40001{
float      Temp;    
float      Humi;    
};
 typedef union pluto {
  packet40001 Data40001; //  Dataxxxxx is the name of the structure to be joined to bufVar
  byte bufVar[MXVAR];   //  array of bytes to be joined with the structure
};
pluto minni;            //  minni is the name of the union type pluto
