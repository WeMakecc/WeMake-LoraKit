//  put here libraries needed for sensors and global variables other than in Packet..  
  //   SHT21

#include <Wire.h>
#include <SHT2x.h>   //  address 0x40
byte SHT21present = 0;
byte error = 0;
